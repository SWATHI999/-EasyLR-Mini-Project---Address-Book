# -*- coding: utf-8 -*-
from django.shortcuts import *
from django.contrib.auth import authenticate,login
from django.contrib.auth.models import User
from .models import *
from django.http import *
import Tkinter as tk
import tkMessageBox
import json
def home(request):
	template = loader.get_template('home.html')
    	context = {}
	return HttpResponse(template.render(context, request))
	
def register(request):
	if request.method == 'POST':
		user=User()
		user.username=request.POST.get('username')
		user.email=request.POST.get('email')
		user.password=request.POST.get('pwd')
		user.save()
		template = loader.get_template('login.html')
    		context = {'success':1}
		return HttpResponse(template.render(context, request))
	else:	
		template = loader.get_template('register.html')
    		context = {}
		return HttpResponse(template.render(context, request))
def login(request):
	if request.method == 'POST':
		if User.objects.get(username=request.POST.get('username')) and User.objects.get(username=request.POST.get('username')).password==request.POST.get('pwd'):
			request.session['username']=request.POST.get('username')
			template = loader.get_template('add.html')	
    			context = {'success':1,'username':request.session['username']}
			return HttpResponse(template.render(context, request))		
		else:
			template = loader.get_template('login.html')
    			context = {'success':0}
			return HttpResponse(template.render(context, request))
	else:
		template = loader.get_template('login.html')
    		context = {'success':2}
		return HttpResponse(template.render(context, request))		
							
					
	
def add(request):
	
	if request.method == 'POST':
		address=Addresses(accountuser=request.session['username'],name=request.POST.get('name'),address=request.POST.get('address'),city=request.POST.get('city'),email=request.POST.get('email'),phonenumber=request.POST.get('phone'))
		address.save()
		root = tk.Tk()
		root.withdraw()
		tkMessageBox.showinfo("Info","Successfully Inserted!")
	template = loader.get_template('add.html')
    	context = {'username':request.session['username']}
	return HttpResponse(template.render(context, request))
def edit(request):
	edit=0
	if request.method == 'POST':
		address=Addresses.objects.all()
		for entry in address:
			if entry.accountuser==request.session['username'] and entry.name==request.POST.get('oldname') and entry.address==request.POST.get('oldaddress') and entry.city==request.POST.get('oldcity') and entry.email==request.POST.get('oldemail') and entry.phonenumber==request.POST.get('oldphone'):
				entry.accountuser=request.session['username']
				entry.name=request.POST.get('newname') 
				entry.address=request.POST.get('newaddress') 
				entry.city=request.POST.get('newcity')
				entry.email=request.POST.get('newemail')
				entry.phonenumber=request.POST.get('newphone')
				entry.save()
				edit=1
				break
	entries=[]
	address=Addresses.objects.all()
	for entry in address:
			if entry.accountuser==request.session['username']:
				entries.append(entry)
	template = loader.get_template('edit.html')
    	context = {'edit':edit,'entries':entries,'username':request.session['username']}
	return HttpResponse(template.render(context, request))
def viewaddress(request):
	locations=[]
	address=Addresses.objects.all()
	for entry in address:
			if entry.accountuser==request.session['username']:
				locations.append(entry.address+','+entry.city)
	template = loader.get_template('view.html')
    	context = {'locations':json.dumps(locations)}
	return HttpResponse(template.render(context, request))
def list_of_all_addresses(request):
	entries=[]
	address=Addresses.objects.all()
	for entry in address:
			if entry.accountuser==request.session['username']:
				entries.append(entry)
	template = loader.get_template('list_addresses.html')
    	context = {'entries':entries,'username':request.session['username']}
	return HttpResponse(template.render(context, request))
	
