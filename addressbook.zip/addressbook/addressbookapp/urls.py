from django.conf.urls import url
from . import views
app_name='addressbookapp'
urlpatterns = [
url(r'^home/$',views.home,name='home'),
url(r'^register/$',views.register,name='register'),
url(r'^login/$',views.login,name='login'),
url(r'^add/$',views.add,name='add'),
url(r'^edit/$',views.edit,name='edit'),
url(r'^list_of_all_addresses/$',views.list_of_all_addresses,name='list_of_all_addresses'),
url(r'^viewaddress/$',views.viewaddress,name='viewaddress'),]
